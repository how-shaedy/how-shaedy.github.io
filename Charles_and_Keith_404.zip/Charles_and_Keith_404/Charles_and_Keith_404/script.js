
document.getElementById('homeButton').addEventListener('click', function() {
    window.location.href = 'https://www.charleskeith.com';
});

document.getElementById('contactButton').addEventListener('click', function() {
    window.location.href = 'https://www.charleskeith.com/sg/contactus'; // Replace with the actual contact page URL
});